"""BOSS visible-page collector. Python standard library only."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import shutil
import statistics
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from urllib.parse import urlsplit, urlencode

HERE = Path(__file__).resolve().parent
STRINGS = ('url title company city location salary_text experience education industry '
           'company_size financing jd query collected_at raw_text published_at employment_type '
           'source_page source_type completeness recruitment_status selected_city company_type '
           'main_direction domain language professional_background responsibilities requirements '
           'preferred_requirements recruitment_count duplicate_note inclusion_reason').split()
KEYWORDS = {
    '语言表达': r'语言表达|文字表达|书面表达|文案|写作',
    '阅读理解': r'阅读理解|文本理解|语义理解',
    '逻辑判断': r'逻辑|推理|判断能力',
    '信息检索': r'信息检索|信息搜集|资料检索|搜索能力|事实核查',
    '标注规范': r'标注规范|标注规则|标注标准',
    '数据质量': r'数据质量|质检|一致性|质量审核|质量控制',
    '模型评测': r'模型评测|大模型评测|模型评估|评测标准|评测指标',
    '大模型知识': r'大模型|LLM|ChatGPT',
    '提示词': r'提示词|prompt',
    'Excel': r'\bExcel\b', 'SQL': r'\bSQL\b', 'Python': r'\bPython\b',
    '协作': r'团队协作|沟通协调|跨团队|跨部门',
    '项目管理': r'项目管理|进度管理|项目交付|交付管理',
}

def now():
    return datetime.now(timezone.utc).isoformat()

def dump(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2))

def canonical(url):
    u = urlsplit(url)
    if u.scheme != 'https' or u.hostname not in ('www.zhipin.com', 'zhipin.com', 'm.zhipin.com'):
        raise ValueError('必须是 HTTPS 的 BOSS 直聘 URL')
    m = re.fullmatch(r'/job_detail/([A-Za-z0-9_~\-]+)\.html', u.path)
    if not m:
        raise ValueError('需要岗位详情链接 /job_detail/<ID>.html')
    return 'https://www.zhipin.com' + u.path

def validate(row):
    if not isinstance(row, dict):
        raise ValueError('每条记录必须是对象')
    for k in STRINGS:
        if k in row and not isinstance(row[k], str):
            raise ValueError(f'{k} 必须是字符串')
    if not row.get('title', '').strip():
        raise ValueError('职位名称为空，拒绝导入')
    tags = row.get('tags', [])
    if not isinstance(tags, list) or not all(isinstance(t, str) for t in tags):
        raise ValueError('tags 必须为字符串数组')
    result = {k: row.get(k, '').strip() for k in STRINGS}
    result['url'] = canonical(row.get('url', ''))
    result['job_id'] = Path(urlsplit(result['url']).path).stem
    result['tags'] = tags
    result['collected_at'] = result['collected_at'] or now()
    datetime.fromisoformat(result['collected_at'].replace('Z', '+00:00'))
    return result

def read_rows(path):
    p = Path(path)
    if not p.exists():
        return []
    content = p.read_text(encoding='utf-8-sig').strip()
    if not content:
        return []
    if content.startswith('['):
        rows = json.loads(content)
    elif content.startswith('{'):
        try:
            obj=json.loads(content)
        except json.JSONDecodeError:
            rows=[json.loads(line) for line in content.splitlines() if line.strip()]
        else:
            rows=obj['observations'] if isinstance(obj,dict) and 'observations' in obj else [obj]
    else:
        rows = [json.loads(line) for line in content.splitlines() if line.strip()]
    return [validate(r) for r in rows]

def append_rows(path, rows):
    checked = [validate(row) for row in rows]
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('a', encoding='utf-8', newline='\n') as f:
        for row in checked:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')
    return checked

def dedupe(rows):
    merged = {}
    for row in sorted(rows, key=lambda r: datetime.fromisoformat(r['collected_at'].replace('Z', '+00:00')).timestamp()):
        key = row['url']
        prior = merged.setdefault(key, {'observations': 0, 'queries': []})
        prior['observations'] += 1
        if row.get('query') and row['query'] not in prior['queries']:
            prior['queries'].append(row['query'])
        prior.update({k: v for k, v in row.items() if v != '' and v != []})
    return list(merged.values())

def salary(text):
    s = re.sub(r'\s', '', text).replace('～', '-').replace('~', '-').replace('—', '-')
    out = {'salary_low': None, 'salary_high': None, 'salary_period': 'unknown', 'salary_months': None}
    months = re.search(r'(\d+(?:\.\d+)?)薪', s)
    if months:
        out['salary_months'] = float(months[1])
    if re.search(r'面议|计件|每件|元/单', s):
        out['salary_period'] = 'negotiable' if '面议' in s else 'piece'
        return out
    m = re.search(r'(\d+(?:\.\d+)?)([kK千万]?)-(\d+(?:\.\d+)?)([kK千万]?)(?:元)?', s)
    if not m:
        m = re.search(r'(\d+(?:\.\d+)?)([kK千万]?)(?:元)?(?=/|每)', s)
        if not m:
            return out
        lo, hi, unit = float(m[1]), float(m[1]), m[2]
    else:
        if m[2] and m[4] and m[2].lower() != m[4].lower():
            return out
        lo, hi, unit = float(m[1]), float(m[3]), m[4] or m[2]
    multiplier = {'k':1000, '千':1000, '万':10000}.get(unit.lower(), 1)
    period = ('year' if re.search(r'/年|每年|年薪', s) else
              'day' if re.search(r'/天|/日|每天|每日', s) else
              'hour' if re.search(r'/时|每小时', s) else
              'month' if re.search(r'/月|每月', s) or unit.lower() in ('k','千') else 'unknown')
    if lo <= hi and period != 'unknown':
        out.update(salary_low=lo*multiplier, salary_high=hi*multiplier, salary_period=period)
    return out

def browser(*args, stdin=None):
    # Windows .cmd is launched by subprocess; arguments originate from CLI or observed URLs.
    exe = shutil.which('agent-browser.cmd' if os.name == 'nt' else 'agent-browser')
    if not exe:
        raise RuntimeError('找不到 agent-browser，请先安装浏览器依赖')
    proc = subprocess.run([exe, '--session', 'boss-research', '--json', *args], input=stdin,
                          encoding='utf-8', errors='replace', capture_output=True, timeout=65)
    try:
        result = json.loads(proc.stdout)
    except json.JSONDecodeError:
        raise RuntimeError(f'浏览器未返回 JSON：{(proc.stderr or proc.stdout)[:400]}')
    if proc.returncode or not result.get('success'):
        raise RuntimeError(str(result.get('error', proc.stderr)))
    return result.get('data')

def extract():
    result = browser('eval', '--stdin', stdin=HERE.joinpath('extract.js').read_text(encoding='utf-8'))
    if isinstance(result, dict) and 'result' in result:
        result = result['result']
    if isinstance(result, str):
        result = json.loads(result)
    if not isinstance(result, dict) or 'kind' not in result:
        raise RuntimeError(f'无法识别浏览器提取结果：{str(result)[:300]}')
    return result

def capture(data, query):
    result = extract()
    if not result['records']:
        return result
    for row in result['records']:
        row['query'] = query
    rows = append_rows(data, result['records'])
    return {'kind':result['kind'], 'url':result['url'], 'count':len(rows),
            'missing_jd':sum(not r['jd'] for r in rows),
            'missing_title':sum(not r['title'] for r in rows)}

def report(args):
    rows = dedupe(read_rows(args.data))
    rows = [r for r in rows if (not args.query or args.query in r['queries'])
            and (not args.city or r.get('city') == args.city)
            and (not args.industry or r.get('industry') == args.industry)]
    for r in rows:
        r.update(salary(r.get('salary_text','')))
    dictionary = json.loads(Path(args.keywords).read_text(encoding='utf-8-sig')) if args.keywords else KEYWORDS
    if not isinstance(dictionary, dict) or not all(isinstance(v, str) for v in dictionary.values()):
        raise ValueError('技能词典格式错误')
    patterns = {k:re.compile(v, re.I) for k,v in dictionary.items()}
    jds = [r for r in rows if r.get('jd')]
    freq = [{'requirement':k, 'mentioned':sum(bool(p.search(r['jd'])) for r in jds),
             'denominator':len(jds), 'rate':sum(bool(p.search(r['jd'])) for r in jds)/len(jds) if jds else None}
            for k,p in patterns.items()]
    salaries = {}
    for period in ('month','day','hour','year'):
        subset = [r for r in rows if r['salary_period'] == period]
        salaries[period] = {'n':len(subset),
            'median_advertised_midpoint':statistics.median((r['salary_low']+r['salary_high'])/2 for r in subset) if subset else None}
    stats = {'unique_jobs':len(rows), 'companies_known':len({r['company'] for r in rows if r.get('company')}),
             'with_jd':len(jds), 'salary':salaries, 'requirements':freq,
             'collected_from':min((r['collected_at'] for r in rows),default=None),
             'collected_to':max((r['collected_at'] for r in rows),default=None),
             'generated_at':now(),
             'filters':{'query':args.query,'city':args.city,'industry':args.industry}}
    for field in ('city','industry','experience','education','salary_period'):
        stats[field] = dict(Counter(r.get(field) or '未知' for r in rows))
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out/'jobs.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'stats.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    columns = ['job_id'] + STRINGS + ['tags','queries','observations','salary_low','salary_high','salary_period','salary_months']
    with (out/'jobs.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer = csv.DictWriter(f,fieldnames=columns,extrasaction='ignore')
        writer.writeheader()
        for r in rows:
            clean = {}
            for k,v in r.items():
                if isinstance(v,list):
                    v = ' | '.join(map(str,v))
                if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')):
                    v = "'"+v
                clean[k]=v
            writer.writerow(clean)
    lines = ['# BOSS 岗位样本统计','',f'去重岗位 {len(rows)} 条；已获取 JD {len(jds)} 条。',
             f'采集范围：{stats["collected_from"]} 至 {stats["collected_to"]}。',
             '','本工具统计采集条目，不能单凭网页可见性确认仍在招聘，须人工核验状态。',
             '关键词命中为 JD 明确提及；不能区分必备、职责或加分项。','',
             '|要求|提及条目|有效 JD 分母|提及率|','|---|---:|---:|---:|']
    for x in freq:
        rate = f'{x["rate"]:.1%}' if x['rate'] is not None else '不可计算'
        lines.append(f'|{x["requirement"]}|{x["mentioned"]}|{x["denominator"]}|{rate}|')
    lines += ['','薪资为招聘广告区间中点的中位数，非实际收入；不同周期分开统计。',
              '未知薪数留空；月薪不自动换算年包。搜索排序、筛选与可访问范围影响样本。',
              '工具不自动合并同公司同名的不同链接，需人工标记疑似重复。']
    (out/'report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return {'out':str(out.resolve()),'unique_jobs':len(rows),'with_jd':len(jds)}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('doctor'); sub.add_parser('status')
    op=sub.add_parser('open'); op.add_argument('--query',default=''); op.add_argument('--url')
    im=sub.add_parser('import'); im.add_argument('--input',required=True); im.add_argument('--data',required=True)
    for cmd in ('capture','details'):
        s=sub.add_parser(cmd); s.add_argument('--data',required=True); s.add_argument('--query',default='')
        if cmd=='details':
            s.add_argument('--max',type=int,default=20); s.add_argument('--interval',type=float,default=3)
    rp=sub.add_parser('report'); rp.add_argument('--data',required=True); rp.add_argument('--out',required=True)
    for flag in ('query','city','industry','keywords'): rp.add_argument('--'+flag,default='')
    a=p.parse_args()
    if a.command=='doctor':
        dump({'python':sys.version.split()[0], 'agent_browser':shutil.which('agent-browser'), 'extractor':(HERE/'extract.js').exists()})
    elif a.command=='import':
        dump({'imported':len(append_rows(a.data,read_rows(a.input)))})
    elif a.command=='open':
        url=a.url or 'https://www.zhipin.com/web/geek/jobs?'+urlencode({'query':a.query})
        u=urlsplit(url)
        if u.scheme!='https' or u.hostname not in ('www.zhipin.com','zhipin.com'):
            raise ValueError('只允许打开 BOSS 直聘 HTTPS 页面')
        dump(browser('--headed','open',url))
    elif a.command=='status':
        r=extract(); r.pop('records',None); dump(r)
    elif a.command=='capture': dump(capture(a.data,a.query))
    elif a.command=='report': dump(report(a))
    elif a.command=='details':
        if not 1<=a.max<=100 or a.interval<3:
            raise ValueError('每批 max 为 1–100，interval 至少 3 秒')
        jobs=[r for r in dedupe(read_rows(a.data)) if not r.get('jd') and (not a.query or a.query in r['queries'])][:a.max]
        results=[]
        for i,row in enumerate(jobs):
            if i: time.sleep(a.interval)
            browser('--headed','open',row['url'])
            time.sleep(2)
            r=capture(a.data,a.query)
            results.append(r)
            if r['kind']!='detail' or not r.get('count') or r.get('missing_jd'):
                break
        dump({'attempted':len(results),'results':results})

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
    try: main()
    except (ValueError,RuntimeError,OSError,subprocess.TimeoutExpired) as exc:
        dump({'error':str(exc)}); sys.exit(1)
