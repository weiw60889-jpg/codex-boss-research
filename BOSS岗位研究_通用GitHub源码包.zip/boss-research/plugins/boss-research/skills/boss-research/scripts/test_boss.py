import argparse
import csv
import json
from pathlib import Path
import tempfile
import unittest
import boss

class DataTests(unittest.TestCase):
    def row(self, **kwargs):
        r = {'url':'https://www.zhipin.com/job_detail/test-id.html?ka=search', 'title':'测试职位',
             'collected_at':'2026-10-19T03:00:00+00:00'}
        r.update(kwargs)
        return boss.validate(r)

    def test_dedupe_preserves_jd_and_queries(self):
        a=self.row(jd='完整职责',query='训练师')
        b=self.row(query='评测',collected_at='2026-10-19T04:00:00+00:00')
        rows=boss.dedupe([b,a])
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['jd'],'完整职责')
        self.assertEqual(rows[0]['queries'],['训练师','评测'])
        self.assertEqual(rows[0]['observations'],2)

    def test_url_boundaries(self):
        for url in ('https://www.zhipin.com.evil.test/job_detail/a.html','https://evil.test/job_detail/a.html',
                    'http://www.zhipin.com/job_detail/a.html','https://www.zhipin.com/web/user/'):
            with self.assertRaises(ValueError): self.row(url=url)

    def test_salary_units(self):
        cases=[('12-16K·14薪',12000,16000,'month',14),('100-300元/时',100,300,'hour',None),
               ('220-300元/天',220,300,'day',None),('30-50万/年',300000,500000,'year',None),
               ('300元/天',300,300,'day',None),('8K-12K',8000,12000,'month',None)]
        for s,lo,hi,period,months in cases:
            x=boss.salary(s)
            self.assertEqual((x['salary_low'],x['salary_high'],x['salary_period'],x['salary_months']), (lo,hi,period,months))
        for s in ('面议','8-12万','计件薪酬','12-8K','8K-1万'):
            self.assertIsNone(boss.salary(s)['salary_low'])

    def test_atomic_validation(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'data.jsonl'
            with self.assertRaises(ValueError): boss.append_rows(p,[self.row(),{'title':'no url'}])
            self.assertFalse(p.exists())

    def test_extension_export_import(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'extension.json'
            p.write_text(json.dumps({'observations':[self.row(source_type='列表摘要',recruitment_status='待核验')],
                                     'unlinked':[{'jd':'不能绑定'}],'logs':[]},ensure_ascii=False),encoding='utf-8')
            rows=boss.read_rows(p)
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0]['source_type'],'列表摘要')
            self.assertEqual(rows[0]['recruitment_status'],'待核验')

    def test_export_and_denominator(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'data.jsonl'
            boss.append_rows(p,[self.row(title='=1+1',jd='Python Python 大模型',salary_text='8-12K'),
                                self.row(url='https://www.zhipin.com/job_detail/second.html',title='摘要')])
            args=argparse.Namespace(data=str(p),out=str(Path(d)/'report'),query='',city='',industry='',keywords='')
            boss.report(args)
            stats=json.loads((Path(args.out)/'stats.json').read_text(encoding='utf-8'))
            self.assertEqual(stats['unique_jobs'],2)
            python=next(x for x in stats['requirements'] if x['requirement']=='Python')
            self.assertEqual((python['mentioned'],python['denominator'],python['rate']),(1,1,1))
            with (Path(args.out)/'jobs.csv').open(encoding='utf-8-sig',newline='') as f:
                self.assertEqual(next(csv.DictReader(f))['title'],"'=1+1")

    def test_empty_report_is_not_zero_percent(self):
        with tempfile.TemporaryDirectory() as d:
            args=argparse.Namespace(data=str(Path(d)/'empty.jsonl'),out=d,query='',city='',industry='',keywords='')
            boss.report(args)
            stats=json.loads((Path(d)/'stats.json').read_text(encoding='utf-8'))
            self.assertIsNone(stats['requirements'][0]['rate'])
            self.assertIsNone(stats['salary']['month']['median_advertised_midpoint'])

if __name__=='__main__': unittest.main()
