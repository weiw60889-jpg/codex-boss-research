"""Visible-list prioritization for an explicitly configured research target.

No built-in AI, sales, or engineering exclusions. Not a JD eligibility classifier.
"""
import re

VERSION='generic-v1'

def validate(config):
 if not isinstance(config,dict):raise ValueError('请传入本次研究配置')
 if not isinstance(config.get('job_title'),str) or not config['job_title'].strip():raise ValueError('请填写目标岗位job_title')
 for key in ['keywords','exclude_keywords']:
  value=config.get(key,[])
  if not isinstance(value,list) or any(not isinstance(x,str) or not x.strip() for x in value):raise ValueError(key+'应为非空字符串组成的数组；无排除词时用空数组')
 return config

def _matches(text,terms):
 return any(term.casefold() in text.casefold() for term in terms if term)

def screen(row,config):
 validate(config)
 title=str(row.get('title',''))
 tags=row.get('tags',[])
 if not isinstance(tags,list):tags=[]
 text=title+' '+' '.join(str(t) for t in tags)
 if _matches(title,config.get('exclude_keywords',[])):
  return 0,'命中本次配置的列表排除词；未读JD，不算已核验排除'
 terms=list(dict.fromkeys([config['job_title'].strip()]+config.get('keywords',[])))
 if _matches(title,terms):return 3,'职位名命中本次目标词，仍需读JD核验职责'
 if _matches(text,terms):return 2,'列表标签命中本次目标词，仍需读JD核验职责'
 return 1,'目标相关性未知的边界候选，低优先；不直接判无关'

def prioritize(rows,config):
 validate(config)
 scored=[(screen(row,config)[0],row) for row in rows]
 best=max((score for score,row in scored),default=0)
 return [row for score,row in scored if score==best and score>0]
