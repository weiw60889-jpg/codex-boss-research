(() => {
  const visible = e => !!e && !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length) && getComputedStyle(e).visibility !== 'hidden';
  const text = e => visible(e) ? e.innerText.trim() : '';
  const first = (root, selectors) => { for (const s of selectors.split(',')) { const e = [...root.querySelectorAll(s.trim())].find(visible); if (text(e)) return text(e); } return ''; };
  const all = (root, s) => [...root.querySelectorAll(s)].filter(visible).map(text).filter(Boolean);
  const body = (document.body?.innerText || '').trim();
  const base = {url: location.href, page_title: document.title, collected_at: new Date().toISOString()};
  if (location.hostname !== 'www.zhipin.com' && location.hostname !== 'zhipin.com') return {...base, kind:'blocked', reason:'当前不是 BOSS 直聘页面', records:[]};
  if (/安全验证|请完成验证|访问过于频繁|访问异常|验证您的身份|滑动验证/.test(body) || /captcha|security-check|verify/.test(location.pathname)) return {...base, kind:'blocked', reason:'页面要求验证或限制访问', records:[]};
  if (/\/web\/(user|passport)\//.test(location.pathname)) return {...base, kind:'blocked', reason:'需要用户登录或验证', records:[]};
  const cards = /\/job_detail\//.test(location.pathname) ? [] : [...document.querySelectorAll('.job-card-wrapper, .job-card-box')].filter(visible);
  const links = [];
  const seen = new Set();
  for (const card of cards) {
    const a = [...card.querySelectorAll('a[href*="/job_detail/"]')].find(visible);
    if (!a || seen.has(a.href)) continue;
    seen.add(a.href);
    const tags = all(card, '.tag-list li, .job-tag-list li');
    const info = all(card, '.company-tag-list li');
    links.push({url:a.href, title:first(card,'.job-name, .job-title'), company:first(card,'.company-name'),
      city:first(card,'.job-area-wrapper .job-area, .job-area').split(/[·\s]/)[0] || '',
      location:first(card,'.job-area-wrapper, .job-area'), salary_text:first(card,'.salary'),
      experience:tags.find(t => /经验|\d+.*年|应届|在校/.test(t)) || '',
      education:tags.find(t => /本科|硕士|博士|大专|高中|中专|学历|初中/.test(t)) || '',
      industry: info[0] || '', financing:info.find(t=>/轮|融资|上市/.test(t)) || '',
      company_size:info.find(t=>/人/.test(t)) || '', tags, jd:'', raw_text:text(card), collected_at:base.collected_at});
  }
  if (links.length) return {...base, kind:'list', records:links};
  if (/\/job_detail\//.test(location.pathname)) {
    const title = first(document,'.job-banner .name h1, .job-banner h1, .job-detail h1');
    const jd = first(document,'.job-sec-text, .job-detail .text');
    const p = first(document,'.job-banner .info-primary p');
    const bits = p.split('\n').map(s=>s.trim()).filter(Boolean);
    if (title) return {...base, kind:'detail', records:[{url:location.href, title,
      salary_text:first(document,'.job-banner .salary'), company:first(document,'.sider-company .company-info a, .company-info .company-name, .company-name'),
      city:first(document,'.job-banner .text-city'), location:first(document,'.job-location .location-address, .location-address'),
      experience:bits.find(t=>/经验|\d+.*年|应届|在校/.test(t)) || '',
      education:bits.find(t=>/本科|硕士|博士|大专|高中|中专|学历/.test(t)) || '',
      industry:'', company_size:'', financing:'', tags:all(document,'.job-banner .job-tags span'),
      jd, collected_at:base.collected_at, raw_text:[title,p,jd].filter(Boolean).join('\n')}]};
  }
  const reason = /扫码登录|登录后查看|请先登录/.test(body) ? '需要用户登录' : '没有识别到岗位：页面可能未加载完成或选择器已变化';
  return {...base, kind:'unrecognized', reason, records:[], preview:body.slice(0,1500)};
})()
