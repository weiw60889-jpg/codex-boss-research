"""Loopback-only bridge between Codex and the ordinary Chrome extension."""
import argparse
from datetime import datetime, timezone
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import secrets
import sys
import threading
import time
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import uuid

PORT=19763
KINDS={'inspect','capture','search','next','scroll','detail'}
def now(): return datetime.now(timezone.utc).isoformat()
def atomic(path,obj):
    temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    temp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    for attempt in range(8):
        try:
            temp.replace(path)
            return
        except PermissionError:
            if attempt==7: raise
            time.sleep(.025*(attempt+1))
def job_url(value):
    u=urlsplit(value)
    if u.scheme!='https' or u.hostname not in ('www.zhipin.com','zhipin.com','m.zhipin.com') or not re.fullmatch(r'/job_detail/[A-Za-z0-9_~\-]+\.html',u.path):
        raise ValueError('只允许已观察的BOSS岗位详情链接')
    return 'https://www.zhipin.com'+u.path
def validate_command(command):
    if not isinstance(command,dict) or command.get('kind') not in KINDS: raise ValueError('命令不在允许列表中')
    result={'kind':command['kind']}
    for key in ('city','query','city_code'):
        if key in command:
            if not isinstance(command[key],str) or len(command[key])>120: raise ValueError('检索参数无效')
            result[key]=command[key]
    if result['kind']=='search':
        if not result.get('city') or not result.get('query') or not re.fullmatch(r'\d{9}',result.get('city_code','')): raise ValueError('搜索需提供城市名、9位城市参数、关键词，且结果须核验')
    if result['kind']=='detail': result['url']=job_url(command.get('url',''))
    return result

class Store:
    def __init__(self,root):
        self.root=Path(root).resolve(); self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'bridge-state.json'; self.lock=threading.RLock()
        self.last_poll_at=None
        self.state=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {
            'token':secrets.token_urlsafe(32),'pair_code':f'{secrets.randbelow(1000000):06d}',
            'extension_origin':None,'attempts':0,'commands':[],'created_at':now()}
        self.save()
    def save(self): atomic(self.path,self.state)
    def enqueue(self,command):
        validated=validate_command(command)
        if validated['kind']=='detail':
            # Only allow links present in already-returned DOM records.
            observed=set()
            for c in self.state['commands']:
                for row in (c.get('result') or {}).get('records',[]):
                    try: observed.add(job_url(row.get('url','')))
                    except (ValueError,TypeError): pass
            if validated['url'] not in observed: raise ValueError('详情链接尚未由本次浏览器采集观察到')
        validated.update(id=uuid.uuid4().hex,status='pending',created_at=now())
        self.state['commands'].append(validated);self.save();return validated
    def next(self):
        for c in self.state['commands']:
            if c['status']=='running': return c
            if c['status']=='pending':
                c.update(status='running',started_at=now());self.save();return c
        return None
    def complete(self,payload):
        c=next((c for c in self.state['commands'] if c['id']==payload.get('command_id')),None)
        if not c: raise ValueError('未知命令ID')
        if c['status'] in ('completed','blocked'): return {'ok':True,'duplicate':True}
        result=payload.get('result')
        if not isinstance(result,dict): raise ValueError('结果需为对象')
        rows=result.get('records',[])
        if not isinstance(rows,list) or len(rows)>1000: raise ValueError('岗位记录格式或数量无效')
        for row in rows:
            if not isinstance(row,dict): raise ValueError('岗位记录需为对象')
            job_url(row.get('url',''))
            if not isinstance(row.get('title'),str) or not row['title'].strip(): raise ValueError('岗位标题为空')
        c.update(result=result,status='blocked' if result.get('blocked') else 'completed',completed_at=now())
        self.save()
        # Rebuild auditable files from durable results: completion retries cannot append twice.
        observations=[];excluded=[];logs=[]
        for item in self.state['commands']:
            r=item.get('result')
            if r is None: continue
            for row in ([] if r.get('observation_only') else r.get('records',[])):
                target=excluded if r.get('blocked') else observations
                target.append({**row,'query':item.get('query',row.get('query','')),
                    'selected_city':item.get('city',''),'command_id':item['id'],
                    'filter_verified':item['kind']=='search' and not r.get('blocked'),
                    'capture_blocked':bool(r.get('blocked'))})
            logs.append({k:v for k,v in item.items() if k not in ('result',)})
            logs[-1].update(url=r.get('url',''),records=len(r.get('records',[])),reason=r.get('reason',''),warning=r.get('warning',''))
        atomic(self.root/'browser-data.json',{'observations':observations,'excluded_observations':excluded,'logs':logs,'exported_at':now()})
        return {'ok':True,'records':len(rows),'blocked':bool(result.get('blocked'))}

class Handler(BaseHTTPRequestHandler):
    server_version='BossLocal/0.2'
    def log_message(self,*args): pass
    @property
    def store(self): return self.server.store
    def origin(self): return self.headers.get('Origin','')
    def host_ok(self): return self.headers.get('Host')==f'127.0.0.1:{self.server.server_port}'
    def origin_ok(self):
        origin=self.origin()
        return not origin or origin==self.store.state.get('extension_origin')
    def authorized(self):
        token=self.headers.get('Authorization','')
        return self.origin_ok() and hmac.compare_digest(token,'Bearer '+self.store.state['token'])
    def reply(self,status,obj):
        data=json.dumps(obj,ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        if self.origin() and self.origin_ok(): self.send_header('Access-Control-Allow-Origin',self.origin())
        self.send_header('Vary','Origin');self.send_header('Cache-Control','no-store')
        self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)))
        self.end_headers();self.wfile.write(data)
    def body(self):
        n=int(self.headers.get('Content-Length','0'))
        if not 0<n<=8_000_000: raise ValueError('请求体大小不正确')
        return json.loads(self.rfile.read(n))
    def do_OPTIONS(self):
        if not self.host_ok(): return self.reply(403,{'error':'Host被拒绝'})
        origin=self.origin()
        allowed=origin==self.store.state.get('extension_origin') or (not self.store.state.get('extension_origin') and re.fullmatch(r'chrome-extension://[a-p]{32}',origin))
        if not allowed: return self.reply(403,{'error':'来源被拒绝'})
        self.send_response(204);self.send_header('Access-Control-Allow-Origin',origin)
        self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers','Content-Type, Authorization')
        self.end_headers()
    def do_GET(self):
        if not self.host_ok(): return self.reply(403,{'error':'Host被拒绝'})
        if not self.authorized(): return self.reply(401,{'error':'请先配对本机扩展'})
        with self.store.lock:
            if self.path=='/next':
                self.store.last_poll_at=now()
                return self.reply(200,{'command':self.store.next()})
            if self.path=='/status':
                return self.reply(200,{'paired':bool(self.store.state.get('extension_origin')),'last_poll_at':self.store.last_poll_at,
                    'commands':self.store.state['commands']})
        return self.reply(404,{'error':'未找到'})
    def do_POST(self):
        if not self.host_ok(): return self.reply(403,{'error':'Host被拒绝'})
        try:
            if self.path=='/pair':
                origin=self.origin()
                if not re.fullmatch(r'chrome-extension://[a-p]{32}',origin): return self.reply(403,{'error':'仅允许Chrome扩展配对'})
                with self.store.lock:
                    s=self.store.state
                    if s.get('extension_origin') and origin!=s['extension_origin']: return self.reply(403,{'error':'已绑定另一扩展'})
                    if s.get('attempts',0)>=5: return self.reply(403,{'error':'连接码失败次数过多，请由Codex重置配对'})
                    body=self.body();code=body.get('code','')
                    if not isinstance(code,str) or not hmac.compare_digest(code,s['pair_code']):
                        s['attempts']=s.get('attempts',0)+1;self.store.save();return self.reply(403,{'error':'连接码不正确'})
                    s['extension_origin']=origin;s['attempts']=0;self.store.save()
                    return self.reply(200,{'token':s['token']})
            if not self.authorized(): return self.reply(401,{'error':'连接未授权'})
            payload=self.body()
            with self.store.lock:
                if self.path=='/enqueue': return self.reply(200,self.store.enqueue(payload))
                if self.path=='/complete': return self.reply(200,self.store.complete(payload))
            return self.reply(404,{'error':'未找到'})
        except (ValueError,TypeError,KeyError) as e: self.reply(400,{'error':str(e)})

def client(root,path,body=None):
    for attempt in range(12):
        try:
            settings=json.loads((Path(root)/'bridge-state.json').read_text(encoding='utf-8'))
            break
        except PermissionError:
            if attempt==11:raise
            time.sleep(.025*(attempt+1))
    req=Request(f'http://127.0.0.1:{PORT}'+path,
        data=None if body is None else json.dumps(body,ensure_ascii=False).encode(),
        headers={'Authorization':'Bearer '+settings['token'],'Content-Type':'application/json'})
    with urlopen(req,timeout=8) as res: return json.load(res)
def command(root,payload,timeout=120):
    queued=client(root,'/enqueue',payload)
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        state=client(root,'/status')
        item=next(c for c in state['commands'] if c['id']==queued['id'])
        if item['status'] in ('completed','blocked'): return item
        time.sleep(2)
    raise RuntimeError('等待扩展执行超时；命令仍保存在队列。先检查连接，不要重复提交。')
def run_plan(root,plan):
    if not isinstance(plan,list) or len(plan)>500: raise ValueError('plan应为最多500个检索条件组成的数组')
    for group in plan:
        search=validate_command({'kind':'search',**{k:group[k] for k in ('city','city_code','query')}})
        pages=group.get('pages',3);details=group.get('details',20)
        if not isinstance(pages,int) or not 1<=pages<=20 or not isinstance(details,int) or not 1<=details<=100: raise ValueError('pages范围1–20，details范围1–100')
        item=command(root,search)
        if item['status']=='blocked': raise RuntimeError(item['result'].get('reason','页面阻断'))
        candidates={}; fingerprints=set();stop='达到统一查看页数/轮次上限'
        for page_index in range(pages):
            result=item['result']
            rows=result.get('records',[])
            fingerprint=tuple(sorted(r['url'] for r in rows))
            if fingerprint in fingerprints: stop='翻页/滚动未获得新结果';break
            fingerprints.add(fingerprint)
            for row in rows: candidates.setdefault(row['url'],row)
            if result.get('empty_state'):stop='页面明确显示无结果';break
            if page_index+1<pages:
                # Prefer an actual next control; fall back to scroll only when none exists.
                item=command(root,{'kind':'next', 'city':group['city'],'query':group['query']})
                if item['status']=='blocked': raise RuntimeError(item['result'].get('reason','页面阻断'))
                if item['result'].get('advanced') is False:
                    item=command(root,{'kind':'scroll','city':group['city'],'query':group['query']})
                    if item['status']=='blocked': raise RuntimeError(item['result'].get('reason','页面阻断'))
        completed=0
        values=list(candidates.values())
        selected=[values[i] for i in sorted({round(i*(len(values)-1)/max(1,details-1)) for i in range(min(details,len(values)))})] if values else []
        for row in selected:
            item=command(root,{'kind':'detail','url':row['url'],'city':group['city'],'query':group['query']})
            if item['status']=='blocked': raise RuntimeError(item['result'].get('reason','详情阻断'))
            completed+=1
        entry={**group,'at':now(),'observed_list_versions':len(fingerprints),'unique_list_jobs':len(candidates),'details_read':completed,'stop_reason':stop}
        with (Path(root)/'research-log.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(entry,ensure_ascii=False)+'\n')
        print(json.dumps(entry,ensure_ascii=False),flush=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work',required=True)
    sub=p.add_subparsers(dest='action',required=True)
    sub.add_parser('serve');sub.add_parser('status');sub.add_parser('pair-code')
    cp=sub.add_parser('command');cp.add_argument('--json',required=True);cp.add_argument('--timeout',type=int,default=120)
    rp=sub.add_parser('run');rp.add_argument('--plan',required=True)
    a=p.parse_args();root=Path(a.work).resolve()
    if a.action=='serve':
        store=Store(root);server=ThreadingHTTPServer(('127.0.0.1',PORT),Handler);server.store=store
        print(json.dumps({'listening':f'127.0.0.1:{PORT}','work':str(root)},ensure_ascii=False),flush=True);server.serve_forever()
    elif a.action=='pair-code':
        s=json.loads((root/'bridge-state.json').read_text(encoding='utf-8'))
        print(json.dumps({'pair_code':s['pair_code'],'paired':bool(s.get('extension_origin'))}))
    elif a.action=='status':
        s=client(root,'/status');print(json.dumps({'paired':s['paired'],'last_poll_at':s.get('last_poll_at'),'commands':[{'id':c['id'],'kind':c['kind'],'status':c['status'],'reason':c.get('result',{}).get('reason','')} for c in s['commands']]},ensure_ascii=False,indent=2))
    elif a.action=='command':print(json.dumps(command(root,json.loads(a.json),a.timeout),ensure_ascii=False,indent=2))
    elif a.action=='run':run_plan(root,json.loads(Path(a.plan).read_text(encoding='utf-8-sig')))
if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    try:main()
    except (ValueError,RuntimeError,OSError,HTTPError) as e:print(json.dumps({'error':str(e)},ensure_ascii=False));sys.exit(1)
