# 普通扩展自动采集

## 连接

保持用户日常 Chrome 中一个已登录、可正常显示岗位的 BOSS 标签页。禁止新建浏览器窗口，不使用 Playwriter、CDP 或 debugger。普通扩展操作该标签页，因此用户在采集期间不宜把绑定页切去其他网站；正常切换其他标签不影响任务。

任务中间目录设为绝对路径 `<工作目录>/work/boss-bridge`。本地服务只监听 `127.0.0.1:19763`，不开放局域网。用 `bridge.py --work <目录> serve` 启动并保持后台运行，Windows 后台启动用隐藏窗口；优先复用本任务已启动的服务，不要终止未知进程来抢占端口。不要显示 bridge-state.json 里的长 token。`pair-code` 命令只显示六位配对码，可给用户首次连接；已配对时优先点“继续自动任务”。

扩展更新文件位于分发目录 `chrome-extension/`，用户在 Chrome 扩展管理页对原扩展点重新加载，必要时按 Chrome 提示启用新增的BOSS/本机服务权限。然后回到BOSS标签页，打开扩展，输入配对码并点“连接并交给 Codex”。扩展不会请求Cookie、debugger或聊天访问权限。

## 先验证再批量

1. `python <bridge.py> --work <目录> command --json '{"kind":"inspect"}'`。从返回结果检查 `records`、`city_labels`、`query_value`、`controls`。inspect 只用于探测DOM，不纳入数据样本；之后使用 capture 或 search 实际采集。未识别到列表或详情时，先用返回的可见控件信息修复选择器；不能将空结果作为成功。
2. 搜索命令：`{"kind":"search","city":"北京","city_code":"101010100","query":"AI训练师"}`。城市参数必须来自实际网站URL或页面资料；结果仍须核验显示城市和搜索框关键词。只有 URL 参数匹配不算核验。工具遇筛选未核验会 blocked，把这些记录放 excluded_observations，不能并入样本。
3. 详情命令：`{"kind":"detail","url":"<本次结果实际观察到的详情URL>","city":"北京","query":"AI训练师"}`。服务拒绝从未返回过的详情链接；扩展必须读到目标URL一致的JD，推荐岗位不会混入详情结果。
4. `next` 或 `scroll` 命令同样带 city/query，使用页面存在的下一页控件或滚动，随后验证显示条件。不要通过隐藏接口抓取数据。

命令超时说明仍在队列中，先 `status`，不要重复入队。验证码或关闭页面导致 blocked 时，说明具体障碍；用户在原页面处理后再点“继续自动任务”。不要自动刷新/换身份/规避验证。

## 批量与研究

用 JSON 文件创建检索计划数组，每项含 city、city_code、query、pages、details，例如：

```json
[{"city":"北京","city_code":"101010100","query":"AI训练师","pages":3,"details":20}]
```

`python <bridge.py> --work <目录> run --plan <绝对计划文件>` 串行执行，输出各城市/查询的进度。pages 是实际列表翻页或滚动轮次上限，不冒充完整遍历；details 是每组按实际页面顺序获取详情的上限。先覆盖用户要求的全部城市/关键词，再按资源加深。不同组用一致深度，披露缺失和实际停止原因。

当前批处理器是透明抽样：列表按页面顺序记录，最多取 details 个链接逐条读取。重复列表会停止；出现验证会立即终止该次运行，不继续其他城市。后续可基于原始日志续做未完成组，不能把未完成组当作无岗位。没有历史数据时不声称增长或收缩。

结果自动保存到中间目录 `browser-data.json`（observations、excluded_observations、命令日志）、`research-log.jsonl`（完成组覆盖日志）；`bridge-state.json` 是含认证密钥的内部运行状态，不交付。原始结果中职位是否在招、发布日期仍需据明确页面信息核验。列表摘要与JD分别标记，异常组和未绑定JD不计入核心统计。

`boss.py import --input <browser-data.json> --data <岗位JSONL>` 导入后再用 report 生成CSV。保留原始 browser-data 作为来源证据，并结合完整JD人工核验主方向、纳入边界、企业类型和必备/加分要求。CLI关键词统计仅为提及率，不能替代这些研究标注。
