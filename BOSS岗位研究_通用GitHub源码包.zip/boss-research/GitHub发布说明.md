# 把通用版发到GitHub

本文件夹已整理为仓库根目录，尚未发布。可用名字：`boss-research`或`codex-boss-research`。简介示例：“通过普通Chrome扩展连接Codex，按自定义岗位采集、核验并分析BOSS招聘JD。”

## 第一次发布，用GitHub网页

1. 登录你自己的GitHub，在右上角“＋”选择“New repository”。
2. 填仓库名称、简介；希望所有人下载就选Public，仅指定人访问就选Private。
3. 本目录已有README和.gitignore，初建空仓库时不必再自动生成重复文件。开源协议由作者选择，本包没有替你指定。
4. 点Create repository。
5. 在空仓库点击上传现有文件的入口；有文件的仓库可用Add file→Upload files。
6. 上传**这个boss-research文件夹里的内容**，让README.md、plugins、chrome-extension、.agents等位于仓库根层，不要多套一层boss-research，也不要只把ZIP作为唯一源码文件上传。
7. 注意`.agents`、`.gitignore`、`.gitattributes`是点开头的目录/文件。资源管理器若没显示，开启隐藏项目；上传后核对`.agents/plugins/marketplace.json`确实存在。网页未带上这些文件时单独补传或使用Git客户端。
8. 填提交说明，如“Initial release”，提交。组织/受保护分支可能要求分支与PR，按仓库规则处理。
9. 从仓库Code→Download ZIP下载一次，完整解压核对README、扩展manifest、本地市场文件和填写页；另一个电脑需自行登录配对并试采，不能复用原状态。
10. 将仓库链接发给别人，告诉对方先下载再安装，双击HTML填写页。GitHub直接点HTML通常看见源码，它不是自动运行的在线采集站点。

你也可以在Releases附上本次干净源码ZIP作为便捷下载；源码仍建议正常提交以便维护。当前没有自动发布脚本，不需要填写GitHub Token到插件。

官方操作参考：[创建仓库](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)、[上传文件](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)。

## 发出链接时可以配这段话

下载仓库ZIP并完整解压，按“先看这里_逐步安装教程.html”安装Codex插件和Chrome扩展。用你自己的BOSS账号登录、自己的六位码连接。连接后双击“填写研究需求.html”，填岗位、城市、行业与有效样本目标，复制生成的提示词发给Codex。先看试采，再继续；岗位范围不限定AI训练师，最后可交付Excel与离线HTML。

## 后续维护

- 保留源码与文档，研究时的work、outputs、bridge-state.json和browser-data.json不提交，.gitignore已配置。
- 发布扩展功能更新时同步更新版本和安装说明；Chrome端需重新加载，Codex插件缓存也可能需刷新。
- 新的行业应修改本次配置与规则，而非把行业特定排除条件写死到通用插件。
- 本包没有借用他人的个人数据作演示。需要真实样例报告时，另行决定是否公开该数据，不从原任务自动复制。
