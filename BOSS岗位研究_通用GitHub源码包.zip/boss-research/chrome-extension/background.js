const BRIDGE='http://127.0.0.1:19763';
let looping=false;
const nap=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const isBoss=value=>{try{const u=new URL(value);return u.protocol==='https:' && ['www.zhipin.com','zhipin.com','m.zhipin.com'].includes(u.hostname);}catch{return false;}};
async function request(path,body) {
  const {bridgeToken}=await chrome.storage.local.get('bridgeToken');
  const response=await fetch(BRIDGE+path,{method:body===undefined?'GET':'POST',
    headers:{'Content-Type':'application/json',...(bridgeToken?{'Authorization':'Bearer '+bridgeToken}:{})},
    ...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(8000)});
  const result=await response.json();
  if(!response.ok) throw new Error(result.error||'本机连接失败');
  return result;
}
async function targetTab() {
  const {researchTabId}=await chrome.storage.local.get('researchTabId');
  if(!Number.isInteger(researchTabId)) throw new Error('请在BOSS标签页点“连接并交给Codex”。');
  const tab=await chrome.tabs.get(researchTabId);
  if(!isBoss(tab.url)) throw new Error('绑定的BOSS标签页已离开网站或关闭，暂停任务。');
  return tab;
}
async function readPage(tabId,action='read') {
  await chrome.scripting.executeScript({target:{tabId},files:['collect.js','automation.js']});
  const results=await chrome.scripting.executeScript({target:{tabId},func:arg=>bossPageState(arg),args:[action]});
  return results[0]?.result;
}
async function waitAndRead(tabId) {
  let result;
  for(let i=0;i<6;i++) {
    await nap(1800);
    const {autoRunning}=await chrome.storage.local.get('autoRunning');
    if(!autoRunning) throw new Error('用户已暂停自动采集');
    const tab=await chrome.tabs.get(tabId);
    if(!isBoss(tab.url)) return {blocked:true,reason:'BOSS标签页变为空白、关闭或离开网站，停止继续导航。'};
    if(tab.status!=='complete') continue;
    result=await readPage(tabId);
    if(result?.blocked || result?.records?.length || result?.empty_state) return result;
  }
  return result ? {...result,blocked:true,reason:'页面未识别到岗位或明确空结果，请检查页面结构后继续。'} : {blocked:true,reason:'页面在等待期内没有可读取内容'};
}
function verifyResult(command,result) {
  if(!result || result.blocked) return {...result,blocked:true};
  if(['search','next','scroll'].includes(command.kind) && command.city && command.query) {
    const cityVerified=result.city_labels?.some(t=>t.replace(/\s/g,'').replace(/市$/,'')===command.city.replace(/市$/,''));
    const queryVerified=result.query_value?.trim()===command.query.trim();
    if(!cityVerified || !queryVerified) return {...result,blocked:true,reason:`筛选未核验：城市${cityVerified?'已确认':'未确认'}，关键词${queryVerified?'已确认':'未确认'}。先检查页面选择器，不将这些结果计入目标城市。`};
  }
  if(command.kind==='detail') {
    const expected=new URL(command.url).pathname;
    const matching=result.records?.filter(r=>new URL(r.url).pathname===expected && r.jd);
    if(matching?.length!==1) return {...result,blocked:true,reason:'未取得与目标岗位链接一致的JD，停止以避免错误归属。'};
    result={...result,records:matching};
  }
  return result;
}
async function execute(command) {
  const tab=await targetTab();
  let result;
  if(command.kind==='search') {
    if(!/^\d{9}$/.test(command.city_code) || !command.city || !command.query) throw new Error('检索条件格式不正确');
    const url='https://www.zhipin.com/web/geek/jobs?'+new URLSearchParams({city:command.city_code,query:command.query});
    await chrome.tabs.update(tab.id,{url});
    result=await waitAndRead(tab.id);
  } else if(command.kind==='detail') {
    if(!isBoss(command.url) || !/^\/job_detail\/[A-Za-z0-9_~\-]+\.html$/.test(new URL(command.url).pathname)) throw new Error('详情URL不合法');
    await chrome.tabs.update(tab.id,{url:command.url});
    result=await waitAndRead(tab.id);
  } else if(command.kind==='next' || command.kind==='scroll') {
    // Check gates before invoking a page control.
    const before=await readPage(tab.id);
    if(before.blocked) return before;
    const action=await readPage(tab.id,command.kind);
    if(action.blocked || action.advanced===false) return {...before,...action};
    result=await waitAndRead(tab.id);
  } else if(command.kind==='capture') result=await waitAndRead(tab.id);
  else if(command.kind==='inspect') result={...(await readPage(tab.id)),observation_only:true};
  else throw new Error('不支持的命令');
  return verifyResult(command,result);
}
async function loop() {
  if(looping) return;
  looping=true;
  try {
    while((await chrome.storage.local.get('autoRunning')).autoRunning) {
      let command;
      try {
        const settings=await chrome.storage.local.get('pendingCommand');
        command=settings.pendingCommand || (await request('/next')).command;
        if(!command) {await nap(3000);continue;}
        await chrome.storage.local.set({pendingCommand:command,autoStatus:'正在执行：'+command.kind});
        let result;
        try {result=await execute(command);} catch(error) {result={blocked:true,reason:error.message};}
        const outcome={command_id:command.id,result,completed_at:new Date().toISOString()};
        await request('/complete',outcome);
        await chrome.storage.local.remove('pendingCommand');
        await chrome.storage.local.set({autoStatus:result.blocked?'已暂停：'+(result.reason||'页面不可读'):'已回传：'+(result.records?.length||0)+'条记录'});
        if(result.blocked) {await chrome.storage.local.set({autoRunning:false});break;}
        await nap(3000);
      } catch(error) {
        await chrome.storage.local.set({autoStatus:'连接中断，已暂停：'+error.message,autoRunning:false});
        break;
      }
    }
  } finally {looping=false;}
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  // Only this extension's popup may start a session; no website message bridge.
  if(sender.id!==chrome.runtime.id || sender.tab) return;
  (async()=>{
    if(message.type==='pair') {
      const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
      if(!isBoss(tab?.url)) throw new Error('请先切换到正常打开的BOSS标签页再连接。');
      const response=await fetch(BRIDGE+'/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code:message.code}),signal:AbortSignal.timeout(8000)});
      const data=await response.json();if(!response.ok) throw new Error(data.error||'配对失败');
      await chrome.storage.local.set({bridgeToken:data.token,researchTabId:tab.id,autoRunning:true,autoStatus:'已连接，等待Codex任务'});
      await chrome.alarms.create('boss-local-loop',{periodInMinutes:.5});
      void loop();return {ok:true};
    }
    if(message.type==='resume') {
      const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
      if(!isBoss(tab?.url)) throw new Error('请在目标BOSS标签页继续。');
      await chrome.storage.local.set({researchTabId:tab.id,autoRunning:true,autoStatus:'继续执行'});void loop();return {ok:true};
    }
    if(message.type==='pause') {await chrome.storage.local.set({autoRunning:false,autoStatus:'用户已暂停'});return {ok:true};}
    throw new Error('不支持的操作');
  })().then(reply).catch(error=>reply({error:error.message}));
  return true;
});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='boss-local-loop') void loop();});
chrome.runtime.onStartup.addListener(()=>void loop());
