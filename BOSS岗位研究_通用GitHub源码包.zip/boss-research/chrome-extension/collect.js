// Executed only on an explicit activeTab user click. Read DOM text; no debugger/API/cookies.
function collectBossPage() {
  const cleanURL = value => {
    try {
      const u = new URL(value, location.href);
      if (!['www.zhipin.com','zhipin.com','m.zhipin.com'].includes(u.hostname)) return '';
      return /^\/job_detail\/[A-Za-z0-9_~\-]+\.html$/.test(u.pathname) ? 'https://www.zhipin.com'+u.pathname : '';
    } catch {return '';}
  };
  const visible = e => Boolean(e && e.getClientRects().length && getComputedStyle(e).visibility!=='hidden');
  const text = e => visible(e) ? e.innerText.trim() : '';
  const redactContacts=s=>s.replace(/\b1[3-9]\d{9}\b/g,'[联系方式已省略]').replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,'[邮箱已省略]').split('\n').filter(l=>!/(?:微信|微?信号|[Vv][Xx])\s*[:：]\s*\S+/.test(l)).join('\n');
  const first = (root, selectors) => {
    for (const selector of selectors.split(',')) {
      const el = [...root.querySelectorAll(selector.trim())].find(visible);
      if (text(el)) return text(el);
    } return '';
  };
  const items = (root, selector) => [...root.querySelectorAll(selector)].filter(visible).map(text).filter(Boolean);
  const base = {collected_at:new Date().toISOString(),source_page:location.origin+location.pathname+location.search};
  if (!['www.zhipin.com','zhipin.com','m.zhipin.com'].includes(location.hostname)) return {error:'请先打开 BOSS 直聘岗位列表或详情页。'};
  const body = document.body?.innerText || '';
  if (/\/web\/(user|passport)\//.test(location.pathname) || /安全验证|请完成验证|访问过于频繁|访问异常|滑动验证/.test(body)) return {error:'页面要求登录或验证。请在网页正常完成后再采集。'};
  // An open detail pane takes precedence over list summaries, so JD is not discarded.
  const scope = [...document.querySelectorAll('.job-detail-container, .job-detail-box, .job-detail, .job-window, .job-banner')].filter(visible);
  const jd = redactContacts(first(document,'.job-sec-text, .job-detail .text'));
  const cards = [...document.querySelectorAll('.job-card-wrapper, .job-card-box')].filter(visible);
  const records = [];
  const seen = new Set();
  for (const card of cards) {
    const a = [...card.querySelectorAll('a[href*="/job_detail/"]')].find(visible);
    const url=cleanURL(a?.href);
    const title=first(card,'.job-name, .job-title');
    if (!url || !title || seen.has(url)) continue;
    seen.add(url);
    const tags=items(card,'.tag-list li, .job-tag-list li');
    const companyTags=items(card,'.company-tag-list li');
    const locationText=first(card,'.job-area-wrapper, .job-area, .company-location');
    records.push({...base,url,title,company:first(card,'.company-name, a.boss-info[href*="/gongsi/"]'),city:locationText.split(/[·\s]/)[0] || '',location:locationText,
      salary_text:first(card,'.salary, .job-salary'),experience:tags.find(t=>/经验|\d+.*年|应届|在校/.test(t)) || '',
      education:tags.find(t=>/本科|硕士|博士|大专|高中|中专|学历|初中/.test(t)) || '',
      industry:companyTags[0]||'',financing:companyTags.find(t=>/融资|上市|轮/.test(t))||'',
      company_size:companyTags.find(t=>/人/.test(t))||'',tags,jd:'',source_type:'列表摘要',completeness:'摘要',
      recruitment_status:'待核验',published_at:''});
  }
  if (jd) {
    let url=cleanURL(location.href);
    // A split pane may identify its selected job using an actual job link or the selected list card.
    const activeCard = cards.find(c=>c.matches('.active, .selected, .job-card-active') || c.querySelector('[aria-selected="true"]'));
    const detailLink=scope.flatMap(el=>[...el.querySelectorAll('a[href*="/job_detail/"]')]).find(a=>cleanURL(a.href));
    url=url || cleanURL(detailLink?.href) || cleanURL(activeCard?.querySelector('a[href*="/job_detail/"]')?.href);
    const title=first(document,'.job-banner .name h1, .job-banner h1, .job-detail-header .job-title, .job-detail .job-title, .job-detail h1');
    const meta=first(document,'.job-banner .info-primary p, .job-detail-header .job-info');
    const applicationEvidence=items(document,'a, button').filter(t=>/^(立即沟通|继续沟通|投递简历|立即投递|马上沟通)$/.test(t));
    const detail={...base,url,title,company:first(document,'.sider-company .company-info a, .job-detail .company-name'),
      city:first(document,'.job-banner .text-city'),location:first(document,'.location-address'),
      salary_text:first(document,'.job-banner .salary, .job-detail-header .salary'),
      experience:meta.split('\n').find(t=>/经验|\d+.*年|应届|在校/.test(t))||'',
      education:meta.split('\n').find(t=>/本科|硕士|博士|大专|高中|中专|学历/.test(t))||'',
      industry:'',company_size:'',financing:'',tags:[],jd,source_type:'岗位详情可见文字',completeness:'JD已读取，字段待核验',
      recruitment_status:/职位已关闭|职位已下线|职位已结束|招聘已结束|已停止招聘|职位已过期|职位不存在/.test(body)?'明确结束':applicationEvidence.length?'页面有求职沟通入口且未显示结束':'页面可见，未确认在招',published_at:'',
      application_evidence:applicationEvidence,job_meta_text:meta};
    detail.detail_page_title=document.title;
    const publicationMatch=body.match(/(?:职位发布时间|岗位发布日期|招聘发布日期|发布时间|发布日期)\s*[:：]?\s*(20\d{2}[-/年]\d{1,2}[-/月]\d{1,2}日?)/);
    detail.published_at=publicationMatch ? publicationMatch[1] : '';
    detail.publication_evidence=publicationMatch ? publicationMatch[0] : '';
    detail.company_profile_text=redactContacts(first(document,'.company-info-box, .sider-company'));
    detail.company_card_text=redactContacts(first(document,'.sider-company'));
    detail.company_fact_nodes=[...document.querySelectorAll('.sider-company *, .company-info-box [class]')].filter(visible).filter(e=>!e.children.length && e.innerText?.trim()).slice(0,30).map(e=>({class_name:e.className,text:redactContacts(e.innerText.trim()).slice(0,180)}));
    if (!url || !title) {
      return {records,unlinked_detail:{...detail,url:'',title:title||'待核验职位名称'},warning:'已读取 JD，但无法可靠绑定岗位链接。请打开独立岗位详情页后再采集；本次 JD 单独保存，不并入统计。'};
    }
    const index=records.findIndex(r=>r.url===url);
    if(index>=0) {
      const summary=records[index];
      records[index]={...summary,...Object.fromEntries(Object.entries(detail).filter(([k,v])=>v!=='' && !(Array.isArray(v)&&v.length===0)))};
    } else records.push(detail);
  }
  if(!records.length) return {error:'未识别到可可靠绑定链接的岗位。网站结构可能变化；没有保存空采集结果。'};
  return {records,warning:jd?'':'当前仅采集到列表摘要。请打开岗位详情后再采集 JD。'};
}
