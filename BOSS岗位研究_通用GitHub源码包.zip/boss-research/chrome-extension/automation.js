// DOM-only helpers injected in the extension's isolated world. No debugger attachment.
async function bossPageState(action) {
  const visible=e=>!!(e && e.getClientRects().length && getComputedStyle(e).visibility!=='hidden');
  const get=selector=>[...document.querySelectorAll(selector)].find(visible);
  const body=document.body?.innerText||'';
  const gate=/安全验证|请完成验证|访问过于频繁|访问异常|滑动验证|验证您的身份/.test(body)
    || /\/web\/(user|passport)\//.test(location.pathname);
  if(gate) return {blocked:true,reason:'BOSS要求登录或安全验证，请用户在现有标签页处理。',url:location.origin+location.pathname};
  if(!['www.zhipin.com','zhipin.com','m.zhipin.com'].includes(location.hostname)) return {blocked:true,reason:'标签页离开BOSS或变为空白，已停止。',url:location.href};
  if(action==='scroll') {
    const candidates=[...document.querySelectorAll('.job-list-box, .job-list-container, .job-list-wrapper, .search-job-result')].filter(visible);
    const box=candidates.find(e=>e.scrollHeight>e.clientHeight+20);
    if(box) box.scrollBy({top:Math.max(500,box.clientHeight*.9),behavior:'instant'});
    else window.scrollTo({top:document.documentElement.scrollHeight,behavior:'instant'});
    return {scrolled:true};
  }
  if(action==='next') {
    const elements=[...document.querySelectorAll('.options-pages a, .options-pages button, .options-pages .ui-icon-arrow-right, .pagination a, .pagination button, [rel="next"], [aria-label="下一页"]')].filter(visible);
    const next=elements.find(e=>/^(下一页|下页|Next|›|»)$/.test(e.innerText.trim()) || /^(下一页|Next)$/i.test(e.getAttribute('aria-label')||'') || e.matches('.ui-icon-arrow-right'));
    if(!next || next.closest('.disabled, [aria-disabled="true"]') || next.disabled) return {advanced:false,reason:'未找到可用的下一页控件；不猜测页码链接。'};
    next.click();
    return {advanced:true};
  }
  const collected=collectBossPage();
  if(action==='read' && /\/web\/geek\/jobs/.test(location.pathname) && collected.records?.length && !window.__bossResearchTwoRound) {
    window.__bossResearchTwoRound=true;
    const firstRecords=collected.records;
    window.scrollTo({top:0,behavior:'instant'});
    await new Promise(resolve=>setTimeout(resolve,1000));
    await bossPageState('scroll');
    await new Promise(resolve=>setTimeout(resolve,1800));
    let after=await bossPageState('post-scroll');
    if(!after.blocked && (after.records||[]).length===firstRecords.length) {
      await new Promise(resolve=>setTimeout(resolve,1800));
      after=await bossPageState('post-scroll');
    }
    if(after.blocked) return after;
    const merged=new Map(firstRecords.map(r=>[r.url,r]));
    for(const r of after.records||[])merged.set(r.url,r);
    return {...after,records:[...merged.values()],list_round_counts:[firstRecords.length,(after.records||[]).length],list_read_method:'同一导航中首次读取+一次滚动到底部读取'};
  }
  const cityElements=[...document.querySelectorAll('.city-current, .city-label, .search-city, .city-name, .city-switch-box, .city-switch, [class*="city-current"]')].filter(visible);
  const cityLabels=cityElements.map(e=>e.innerText.trim()).filter(t=>t.length<35);
  const input=get('input[placeholder*="搜索职位"], input[placeholder*="搜索岗位"], input.search-input');
  const controls=[...document.querySelectorAll('a,button,[role="button"]')].filter(visible)
    .filter(e=>/城市|北京|上海|下一页|工作区域|经验|学历/.test(e.innerText)).slice(0,25)
    .map(e=>({text:e.innerText.trim().slice(0,60),className:e.className,href:e.tagName==='A'?e.getAttribute('href'):null}));
  const diagnostics={
    viewport:{height:innerHeight,bodyHeight:document.body.scrollHeight,docHeight:document.documentElement.scrollHeight,scrollY},
    pagination:[...document.querySelectorAll('a,button,[role="button"],span,div')].filter(visible).filter(e=>e.children.length===0 && /^(下一页|上一页|加载更多|查看更多|没有更多了|暂无更多|登录后查看更多|到底了|[1-9][0-9]?)$/.test(e.innerText?.trim()||'')).slice(-20).map(e=>({tag:e.tagName,cls:e.className,text:e.innerText})),
    list_parents:(()=>{const a=[];let e=document.querySelector('.job-card-box,.job-card-wrapper');for(let i=0;e&&i<7;i++,e=e.parentElement)a.push({tag:e.tagName,cls:e.className,height:e.clientHeight,scrollHeight:e.scrollHeight,overflow:getComputedStyle(e).overflowY});return a;})(),
    scroll_containers:[...document.querySelectorAll('div,main,section,ul')].filter(visible).filter(e=>e.scrollHeight>e.clientHeight+80 && e.clientHeight>150).slice(0,15).map(e=>({cls:e.className,height:e.clientHeight,scrollHeight:e.scrollHeight,top:e.scrollTop,overflow:getComputedStyle(e).overflowY})),
    cards:[...document.querySelectorAll('.job-card-wrapper, .job-card-box')].filter(visible).slice(0,1).map(card=>[...card.querySelectorAll('*')].filter(visible).slice(0,60).map(e=>({tag:e.tagName,cls:e.className,text:e.children.length?'':e.innerText?.slice(0,120)}))),
    inputs:[...document.querySelectorAll('input')].filter(visible).slice(0,12).map(e=>({placeholder:e.getAttribute('placeholder'),className:e.className})),
    cities:[...document.querySelectorAll('[class*="city"]')].filter(visible).filter(e=>e.innerText.trim().length<45).slice(0,25).map(e=>({text:e.innerText.trim(),className:e.className})),
    headings:[...document.querySelectorAll('h1,h2,h3')].filter(visible).filter(e=>!e.closest('.job-boss-info,.boss-info')).slice(0,20).map(e=>({text:e.innerText.trim().slice(0,100),className:e.className,parentClass:e.parentElement?.className})),
    job_links:[...document.querySelectorAll('a[href*="/job_detail/"]')].filter(visible).slice(0,12).map(e=>({text:e.innerText.trim().slice(0,80),href:e.getAttribute('href'),className:e.className,parentClass:e.parentElement?.className,grandparentClass:e.parentElement?.parentElement?.className}))
  };
  return {url:location.href,page_title:document.title,city_labels:cityLabels,query_value:input?.value||'',diagnostics,
    controls,records:collected.records||[],unlinked_detail:collected.unlinked_detail||null,
    warning:collected.error||collected.warning||'',empty_state:/没有找到|暂无相关职位|暂无符合/.test(body)};
}
