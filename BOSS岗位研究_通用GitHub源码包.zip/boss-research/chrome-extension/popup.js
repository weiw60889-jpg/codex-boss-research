const byId = id => document.getElementById(id);
const show = message => {byId('status').textContent=message;};
async function refresh() {
  const data=await chrome.storage.local.get({observations:[],unlinked:[],query:'',city:''});
  const rows=data.observations;
  byId('counts').textContent=`本地保存 ${rows.length} 次记录 · ${new Set(rows.map(r=>r.url)).size} 个岗位链接 · ${data.unlinked.length} 条待绑定 JD`;
  return data;
}
byId('capture').addEventListener('click',async()=>{
  byId('capture').disabled=true;
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    const url=new URL(tab.url||'');
    if(url.protocol!=='https:' || !['www.zhipin.com','zhipin.com','m.zhipin.com'].includes(url.hostname)) throw new Error('请在 BOSS 直聘岗位页打开本扩展。');
    // Default isolated execution world: no debugger attachment or page script patching.
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['collect.js']});
    const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>collectBossPage()});
    if(result.error) throw new Error(result.error);
    const data=await refresh();
    const query=byId('query').value.trim(), city=byId('city').value.trim();
    const records=(result.records||[]).map(r=>({...r,query,selected_city:city,city:r.city||city}));
    const unlinked=result.unlinked_detail?[...data.unlinked,{...result.unlinked_detail,query,selected_city:city}]:data.unlinked;
    const batch={at:new Date().toISOString(),source_page:url.origin+url.pathname+url.search,query,selected_city:city,
      records:records.length,with_jd:records.filter(r=>r.jd).length,warning:result.warning||''};
    const {logs=[]}=await chrome.storage.local.get('logs');
    await chrome.storage.local.set({observations:[...data.observations,...records],unlinked,logs:[...logs,batch],query,city});
    show(`本次保存 ${records.length} 条岗位记录，其中 ${records.filter(r=>r.jd).length} 条有 JD。\n${result.warning||''}`);
    await refresh();
  } catch(e) {show(e.message||String(e));}
  finally {byId('capture').disabled=false;}
});
byId('download').addEventListener('click',async()=>{
  try {
    const {observations=[],unlinked=[],logs=[]}=await chrome.storage.local.get(['observations','unlinked','logs']);
    if(!observations.length && !unlinked.length) throw new Error('还没有可下载的记录，请先采集一个岗位页面。');
    const content={schema_version:'0.1',exported_at:new Date().toISOString(),observations,unlinked,logs};
    const blob=new Blob([JSON.stringify(content,null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob);
    await chrome.downloads.download({url,filename:`boss-research-${new Date().toISOString().replace(/[:.]/g,'-')}.json`,saveAs:true});
    show('已发起本地下载。把 JSON 文件交给 Codex 即可分析。');
    setTimeout(()=>URL.revokeObjectURL(url),30000);
  } catch(e) {show(e.message||String(e));}
});
byId('clear').addEventListener('click',async()=>{
  if(!confirm('确认清空本扩展保存的岗位记录？建议先下载备份。')) return;
  await chrome.storage.local.remove(['observations','unlinked','logs']);
  show('已清空本地记录。');await refresh();
});
refresh().then(data=>{byId('query').value=data.query;byId('city').value=data.city;}).catch(e=>show(e.message));
async function autoState(){const {autoStatus='尚未连接本机服务'}=await chrome.storage.local.get('autoStatus');byId('auto-status').textContent=autoStatus;}
for(const [id,type] of [['connect','pair'],['resume','resume'],['pause','pause']]) {
  byId(id).addEventListener('click',async()=>{
    byId(id).disabled=true;
    try {
      const result=await chrome.runtime.sendMessage({type,code:byId('pair-code').value.trim()});
      if(result?.error) throw new Error(result.error);
      await autoState();
    }catch(error){byId('auto-status').textContent=error.message;}
    finally{byId(id).disabled=false;}
  });
}
autoState();setInterval(autoState,1500);
